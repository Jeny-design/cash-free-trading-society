
document.getElementById('register-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Registration functionality is not available in static mode.');
});

document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Login functionality is not available in static mode.');
});

document.getElementById('item-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const title = document.getElementById('item-title').value;
    const description = document.getElementById('item-description').value;
    const image = document.getElementById('item-image').value;
    const item = { title, description, image, owner: 'You' };

    let items = localStorage.getItem('items');
    if (items) {
        items = JSON.parse(items);
    } else {
        items = [];
    }
    items.push(item);
    localStorage.setItem('items', JSON.stringify(items));
    loadItems();
    alert('Item listed successfully.');
});

function loadItems() {
    const itemsContainer = document.getElementById('items-container');
    let items = localStorage.getItem('items');
    itemsContainer.innerHTML = '';

    if (items) {
        items = JSON.parse(items);
        items.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'item';
            itemDiv.innerHTML = `
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <img src="${item.image}" alt="${item.title}">
                <p>Owner: ${item.owner}</p>
            `;
            itemsContainer.appendChild(itemDiv);
        });
    }
}

document.addEventListener('DOMContentLoaded', loadItems);
